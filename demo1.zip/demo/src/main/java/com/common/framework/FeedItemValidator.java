package com.common.framework;

public class FeedItemValidator<I, O> {

}
