package com.common.framework;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.List;

import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.example.demo.FeedItemReader;

public class CustomFieldFeedItemReader<T> extends FeedItemReader<T> implements ItemStream {
	
	private File file;
	private BufferedReader reader;
	private Class<T> type;
	private CustomLineTokenizer lineTokenizer;
	private Method setter;
	private String[] comments;
	private Resource resource;
	private int linesToSkip;

	/**
	
	private SpringFlatFeedItemReader(String baseLocation, String fileName, String[] dtoFieldsName,
			Class<? extends T> dtoClass, String delimiter, int linesToSkip, String[] comments) {
		DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setNames(dtoFieldsName);
		lineTokenizer.setDelimiter(delimiter);

		BeanWrapperFieldSetMapper<T> filedSetMapper = new BeanWrapperFieldSetMapper<T>();
		filedSetMapper.setTargetType(dtoClass);

		DefaultLineMapper<T> defaultLineMapper = new DefaultLineMapper<>();
		defaultLineMapper.setLineTokenizer(lineTokenizer);
		defaultLineMapper.setFieldSetMapper(filedSetMapper);

		this.fileReader = new FlatFileItemReader<T>();
		this.fileReader.setResource(new FileSystemResource(baseLocation + "/" + fileName));
		this.fileReader.setLinesToSkip(linesToSkip);
		this.fileReader.setComments(comments);
		this.fileReader.setLineMapper(defaultLineMapper);
**/

	private CustomFileFeedItemReader(String baseLocation, String fileName, Class<T> type,int linesToSkip,
			 String delimiter, int linesToSkip, String[] comments) throws Exception{
	
		this.initialize(baseLocation,fileName,linesToSkip,comments,type, new DelimitedLineTokenizerAdapter(delimiter));
	}
	private CustomFileFeedItemReader(String baseLocation, String fileName, Class<T> type,int linesToSkip,
			 String delimiter, int linesToSkip, String[] comments) throws Exception{
	
		this.initialize(baseLocation,fileName,linesToSkip,comments,type, new FixedLengthTokenizerAdapter(delimiter));
	}
	
	private void initialize(String baseLocation, String fileName, Class<T> type,int linesToSkip,
			 String delimiter, int linesToSkip, String[] comments) throws Exception{
		this.file=new File(baseLocation, fileName);
		this.resource=new FileSystemResource(baseLocation+"/"+fileName);
		this.linesToSkip=linesToSkip;
		this.comments=comments;
		this.lineTokenizer=lineTokenizer;
		this.type=type;
		this.setter=type.getMethod("setValues", String[].class);
		if(this.setter==null) {
			throw new IllegalArgumentException("setValues(String[j] not found in " +type.toString());
		}
	
		
	}
	
	@Override
	protected T doRead() throws Exception {
		String line;
		do {
			line=reader.readLine();
			if(line==null) {
				return null;
			}
		}while(needToIgnore(line));
		String[] values=lineTokenizer.tokenizeline(line);
		T t=this.type.newInstance();
		this.setter.invoke(t, (Object)values);
		return t;
		
	}
	
	
	
	private boolean needToIgnore(String line) {
		if(line.trim().isEmpty()) {
			return true;
		}
		if(comments!=null) {
			for(String prefix:comments) {
			if(line.startsWith(prefix)) {
				return true;
			}}
		}
		return false;
	}
	@Override
	public void open(ExecutionContext executionContext) throws ItemStreamException {
		try {
			reader=new BufferedReader(new InputStreamReader(this.resource.getInputStream()));
			//reader=new BufferedReader(new InputStreamReader(new FileInputStream(file));
			
			for(int i=1;i<=linesToSkip;i++) {
				reader.readLine();
			}
		}catch (Exception e) {
			throw new ItemStreamException(e);
		}
		
		
	}

	@Override
	public void update(ExecutionContext executionContext) throws ItemStreamException {
		
	}

	@Override
	public void close() throws ItemStreamException {
		try {
			this.reader.close();
		}catch (Exception e) {
			throw new ItemStreamException(e);
		}
	}
	
	private interface CustomLineTokenizer{
		
		public List<String> doTokenizeLine(String line);
		public default String[] tokenizeLine(String line) {
			List<String> tokens=this.doTokenizeLine(line);
			String[] values=new String[tokens.size()];
			for(int i=0;i<=values.length;i++) {
				values[i]=tokens.get(i).trim();
			}
			
			return values;
				
		} 
	}
	private class DelimitedLineTokenizerAdapter extends DelimitedLineTokenizer implements CustomLineTokenizer{
		private DelimitedLineTokenizerAdapter(String delimiter) {
			setDemiter(delimeter);
		}
		public List<String> doTokenizerLine(String line){
			return super.doTokenize(line);
		}
	}


}
