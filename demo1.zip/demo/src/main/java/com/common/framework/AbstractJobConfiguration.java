package com.common.framework;

import javax.batch.api.chunk.ItemReader;
import javax.batch.api.chunk.ItemWriter;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.TaskExecutor;

import com.example.demo.AbstractConfiguration;
import com.example.demo.FeedItem;
import com.example.demo.FeedItemReader;
import com.example.demo.FeedItemWriter;
import com.example.demo.FeedLoadingListener;

@EnableAutoConfiguration
public abstract class AbstractJobConfiguration<I,O extends FeedItem> extends AbstractConfiguration {

	@Bean
	public Job loadingJob(@Autowired FeedLoadingListener feedLoadingListener, @Autowired Step loadingStep) {
		return jobBuilderFactory.get(jobName())
				.listener(feedLoadingListener).start(loadingStep)
				.build();
				
	}
	
	@Bean
	public Step loadingStep(@Autowired ItemReader<I> reader,@Autowired ItemProcessor<I, O> processor, @Autowired ItemWriter<O>
		writer, @Autowired TaskExecutor taskExecutor) {
			return this.stepBuilderFactory.get("loadingStep")
					.<I,O>chunk(chunkSize())
					.reader(reader)
					.writer(writer)
					.taskExecutor(taskExecutor)
					.throttleLimit(throttleLimit())
					.build();
		
	}
	@Bean
	@StepScope
	protected FeedItemWriter<O> writer(@Value("#(jobParameters['FEED_ID'])") Integer feedId){
		FeedItemWriter<O> writer=writer(integer);
		writer.setFeedId(feedId==null?0:feedId);
		writer.initialize();
		return writer;
	}
	@Bean
	@StepScope
	protected abstract FeedItemReader<I> reader(@Value("#(jobParameters['FILE_NAME'])") String fileName,
			@Value("#(jobParameters['HEADERS'])") String headerPattern ,
			@Value("#(jobParameters['FOOTERS'])") String footerPattern ){
	}
	
	@Bean
	protected abstract FeedItemValidator<I,O> processor();
	
			protected abstract String jobName();
			protected abstract String chunkSize();
			protected abstract int throttleLimit();
			
			protected abstract FeedItemWriter<O> writer();
			
			
	
}
