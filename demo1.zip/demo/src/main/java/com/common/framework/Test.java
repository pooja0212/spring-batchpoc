package com.common.framework;

public class Test {

}
