package com.example.demo;

public class TaskStatus {
	
	public enum Status{
		SUCCESS,FAILED_STOP,FAILED_CONTINUE,THRESHOLD_STOP
	}
	private Status status;
	private static String errorDesc;
	
	private TaskStatus() {
		
	}

	public Status getStatus() {
		return status;
	}

	public String getErrorDesc() {
		return errorDesc;
		
	}
	
	public static TaskStatus successStatus() {
		TaskStatus taskStatus=new TaskStatus();
		taskStatus.status=Status.SUCCESS;
		
		return taskStatus;
	}
	
	public static TaskStatus failedStatus(String errorDesc) {
		TaskStatus taskStatus=new TaskStatus();
		if(errorDesc.equals("threshold check failed".trim())) {
			taskStatus.status=Status.THRESHOLD_STOP;
			taskStatus.errorDesc=errorDesc;
			return taskStatus;
			
		}else {
			taskStatus.status=Status.FAILED_STOP;
			taskStatus.errorDesc=errorDesc;
			

		return taskStatus;
		}		
	}
	public static TaskStatus failedStatusButContinue(String errorDesc)
	{
		TaskStatus taskStatus=new TaskStatus();
		taskStatus.status=Status.FAILED_CONTINUE;
		taskStatus.errorDesc=errorDesc;
		return taskStatus;
	
	}
	
}



