package com.example.demo;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

public class RemoveFileTask implements ProcessingTask{
	
	private File sourceDirectory;
	
	
	public RemoveFileTask(String directory) {
		this.sourceDirectory=new File(directory);
	}
	

	@Override
	public TaskStatus execute(String fileName, int feedId, int runId) {
		File filetoRemove=new File(sourceDirectory,fileName);
		if(!filetoRemove.exists()) {
			return TaskStatus.successStatus();
		}
		try {
			FileUtils.forceDelete(filetoRemove);
			
		}
		catch(IOException e) {
			//log.error("");
			return TaskStatus.failedStatusButContinue(e.getMessage());
		}
		return TaskStatus.successStatus();
	}

}
