package com.example.demo;

import java.sql.Types;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;

public class LandingToStagingTransferTask extends StoredProcedureImpl implements PostProcessingTask{

	private static final String PROC_NAME= "pkg.src_to_tgt.mapToSourceTarget";
	public LandingToStagingTransferTask(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PROC_NAME);
	}
	
	public void init() {
		SqlParameter feedId=new SqlParameter("feedid", Types.INTEGER);
		SqlParameter runId=new SqlParameter("runID", Types.INTEGER);
		this.prepareProcedureCall(feedId,runId);
	}

	@Override
	public TaskStatus execute(String fileName, int feedId, int runId) {
	
		Map storedProcResult=this.executeProcedure(feedId,runId);
		
		return storedProcResult !=null ?TaskStatus.successStatus():TaskStatus.failedStatus("landing to staging data movement failed");
	}

}
