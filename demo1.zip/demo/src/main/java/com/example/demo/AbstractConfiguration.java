package com.example.demo;

import java.util.Arrays;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.MapJobRepositoryFactoryBean;
import org.springframework.batch.support.transaction.ResourcelessTransactionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

public class AbstractConfiguration {
	public static final String FILE_NAME_KEY = "FILE_NAME";

	public static final String FEED_ID_KEY = "FEED_ID";
	public static final String RUN_ID_KEY = "RUN_ID";
	public static final String HEADER_PATTERN_KEY = "HEADERS";
	public static final String FOOTER_PATTERN_KEY = "FOOTERS";
	@Value("${feed_file_location}")
	private String processingDir;
	@Value("${rejected_file_dir_path}")
	private String badFilesDir;
	@Autowired
	protected DataSource dataSource;
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	protected JobBuilderFactory jobBuilderFactory;
	@Autowired
	protected StepBuilderFactory stepBuilderFactory;
	@Autowired
	protected FeedLoadingListener feedLoadingListener;
	
	//below is project specific bean to get db ssl obje
	

	@Bean
	public JobLauncher jobLauncher(@Autowired JobRepository jobRepository) {
		SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
		jobLauncher.setJobRepository(jobRepository);
		return jobLauncher;
	}
	
	/**
	 * if we enable below bean will not allow common spring table to insert any thing
	 * for that we need to disable this. i have commented out.
	 */
	/*@Bean
	public JobRepository jobRepository() throws Exception{
		return new MapJobRepositoryFactoryBean(transactionManager()).getObject();
	}
	@Bean
	public PlatformTransactionManager transactionManager() {
		
		return new ResourcelessTransactionManager();
	}*/
	
	@Bean
	private JobStopper jobStopper(JobRepository jobRepository) {
		return new JobStopper();
		
	}
	
	
	@Bean
	public FeedLoadingListener feedLoadingListener(@Autowired JobRepository jobRepository) {
		return new FeedLoadingListener(feedLoadingMonitor(),jobStopper(jobRepository));
	}

	protected FeedLoadingMonitor feedLoadingMonitor() {
		FeedLoadingMonitorImpl feedLoadingMonitor=new FeedLoadingMonitorImpl();
		feedLoadingMonitor.setErrorProcessingTask(getErrorProcessingTasks());
		feedLoadingMonitor.setThresholdErrorProcessingTask(getThresholdErrorProcessingTasks());
		feedLoadingMonitor.setPostProcessingTask(getPostProcessingTasks());
		feedLoadingMonitor.setPreProcessingTask(getPreProcessingTasks());

		return feedLoadingMonitor;
	}
	
	private List<ProcessingTask> getPreProcessingTasks() {
		
		return Arrays.asList(getTruncateTableTask());
	}

	private ProcessingTask getTruncateTableTask() {
		TruncateLandingTableTask task=new TruncateLandingTableTask(this.jdbcTemplate);
		task.init();
		return task;
	}

	private List<ProcessingTask> getPostProcessingTasks() {
		
		return Arrays.asList(thresholdCheckTask(),
				             runIdMapper(),
				             landingToStagingMovementTask(),
				             removeFileTask())	 			
				;
	}

	private ProcessingTask runIdMapper() {
		RunIdMapperTask task=new RunIdMapperTask(this.jdbcTemplate);
		task.init();
		return task;
	}

	private ProcessingTask thresholdCheckTask() {
		ThresholdCheckTask task=new ThresholdCheckTask(this.jdbcTemplate);
		task.init();
		return task;
	}

	private Object landingToStagingMovementTask() {
		LandingToStagingTransferTask task=new LandingToStagingTransferTask(this.jdbcTemplate);
		task.init();
		return task;
	}

	private ProcessingTask removeFileTask() {
	
		return new RemoveFileTask(this.processingDir);
	}

	private List<ProcessingTask> getThresholdErrorProcessingTasks() {
		
		return Arrays.asList(fileMoveToBadDirTask());
	}

	private List<ProcessingTask> getErrorProcessingTasks() {
		
		return Arrays.asList(updateFeedStatusToFailed(), fileMoveToBadDirTask());
	}

	private ProcessingTask updateFeedStatusToFailed() {
		
		return new UpdateFeedFailedTask(this.jdbcTemplate);
	}

	private ProcessingTask fileMoveToBadDirTask() {
	
		return new FileMovingTask(this.processingDir, this.badFilesDir);
	}

	@Bean
	@StepScope
	public TaskExecutor taskExecutor(@Value("#{jobParameters['FILE_NAME']}") String fileName,
			@Value("#{jobParameters['FEED_ID']}") Integer feedId,
			@Value("#{jobParameters['RUN_ID']}") Integer runId) {
				return new SimpleAsyncTaskExecutor(fileName+" "+feedId+" "+runId);
		
	}
	
	
	
}
