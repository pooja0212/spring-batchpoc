package com.example.demo;

public class ExchangeJobConfiguration {

}
