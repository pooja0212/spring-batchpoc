package com.example.demo;

public interface FeedLoadingMonitor {
	public void beforeStart(String fileName,int feedId,int runId);

	public void afterCompletion(String fileName,int feedId,int runId);
	public void onError(Exception e,String fileName,int feedId,int runId);

}
