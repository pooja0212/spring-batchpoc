package com.example.demo;

import java.util.List;

import org.springframework.scheduling.config.Task;

public class FeedLoadingMonitorImpl implements FeedLoadingMonitor{
	
	private long startTime;
	private List<ProcessingTask> preProcessingTask ;
	private List<ProcessingTask> postProcessingTask ;
	private List<ProcessingTask> errorProcessingTask ;
	private List<ProcessingTask> thresholdErrorProcessingTask ;

	private boolean errorOccured =false;
	
	public void setPreProcessingTask(List<ProcessingTask> emptyList) {
		this.preProcessingTask = emptyList;
	}

	public void setPostProcessingTask(List<ProcessingTask> postProcessingTask) {
		this.postProcessingTask = postProcessingTask;
	}

	public void setErrorProcessingTask(List<ProcessingTask> errorProcessingTask) {
		this.errorProcessingTask = errorProcessingTask;
	}

	public void setThresholdErrorProcessingTask(List<ProcessingTask> thresholdErrorProcessingTask) {
		this.thresholdErrorProcessingTask = thresholdErrorProcessingTask;
	}

	@Override
	public void beforeStart(String fileName, int feedId, int runId) {
		//log.info(""Starting loading job for File :" +fileName+,"feedId: " +feedId+ ",runId"+runId");
		startTime=System.currentTimeMillis();
		this.preProcessingTask.forEach(task ->task.execute(fileName, feedId, runId));
	}

	@Override
	public void afterCompletion(String fileName, int feedId, int runId) {
	//log.debug("Completed : Loading data to landing table in ",+(System.currentTimeMillis() -startTime));
		//log.info("Completed : Loading data to landing table");
		if(!this.errorOccured) {
			//log.info("Starting post processing task:: ")
			
			for(ProcessingTask task :postProcessingTask) {
				TaskStatus status=task.execute(fileName, feedId, runId);
				if(TaskStatus.Status.FAILED_STOP.equals(status.getStatus())) {
					//log.error("Post processing task failed_stop status ::"+task+" feedId");
					onError(new Exception(status.getErrorDesc()), fileName, feedId, runId);
					break;
				}
				if(TaskStatus.Status.THRESHOLD_STOP.equals(status.getStatus())) {
					onThresholdError(new Exception(status.getErrorDesc()),fileName,feedId,runId);
					//log.error("Post processing task threshold task THRESHOLD_STOP :: "+task+" failed ");
					break;
				}
				
			}
			//log.info("Completed ::  Post Processing task");
		}

	}

	private void onThresholdError(Exception exception, String fileName, int feedId, int runId) {
		//log.error("Error During job processing in threshold proc ", e);
		this.errorOccured=true;
		this.thresholdErrorProcessingTask.forEach( task ->task.execute(fileName, feedId, runId));
		//log.info("Compelted : Error Processing task in threshold task");;
	}

	@Override
	public void onError(Exception e, String fileName, int feedId, int runId) {
		//log.error("Error during job Processing ",e);
		//log.info("Starting : Error Processing task");
		this.errorOccured=true;
		
		this.errorProcessingTask.forEach(task ->task.execute(fileName, feedId, runId));
		//log.info("Compelted : Error Processing task");
		
		
	}

	
}
