package com.example.demo;

import java.sql.Types;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;

public class TruncateLandingTableTask  extends StoredProcedureImpl implements PostProcessingTask {
	static String procName= "pkg.src_to_tgt.mapToSourceTarget";
	

	public TruncateLandingTableTask(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, procName);
	}

	private static final String PROC_NAME = "pkg.truncate_Table";

	
	public void init() {
		SqlParameter feedId = new SqlParameter("feedid", Types.INTEGER);
			this.prepareProcedureCall(feedId);
	}

	@Override
	public TaskStatus execute(String fileName, int feedId, int runId) {

		Map result=this.executeProcedure(feedId);
	
		// .log.info("update check resut value {}, "+ result);

		return (result != null ?TaskStatus.successStatus() 
				: TaskStatus.failedStatus("landing table failed"));
	}


}
