package com.example.demo;

import java.sql.Types;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;

public class RunIdMapperTask extends StoredProcedureImpl implements PostProcessingTask {
	private static final String PROC_NAME = "pkg.run_id_mapper";
	
	public RunIdMapperTask(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PROC_NAME);
		// TODO Auto-generated constructor stub
	}


	
	public void init() {
		SqlParameter feedId = new SqlParameter("feedid", Types.INTEGER);
		SqlParameter runId = new SqlParameter("runID", Types.INTEGER);
		SqlOutParameter sqlOptMsg=new SqlOutParameter("PROC_OUT_PARAM",Types.INTEGER);
		this.prepareProcedureCall(feedId, runId,sqlOptMsg);
	}

	@Override
	public TaskStatus execute(String fileName, int feedId, int runId) {

		Map<String, Object> result=this.executeProcedure(feedId, runId);
	
		// .log.info("update check resut value {}, "+ result);

		return (result != null && Integer.valueOf(0).equals(result.get("PROC_OUT_PARAM")) ?TaskStatus.successStatus() 
				: TaskStatus.failedStatus("RUN id mapper Proc failed"));
	}


}
