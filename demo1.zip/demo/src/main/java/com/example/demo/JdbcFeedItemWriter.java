package com.example.demo;

import org.springframework.batch.item.file.FlatFileItemWriter;

public class JdbcFeedItemWriter <T extends FeedItem> extends FlatFileItemWriter<T>{

}
