package com.example.demo;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;


public class FileMovingTask implements ProcessingTask{

	private String sourceDirectory;
	private String targetDirectory;
	
	public FileMovingTask(String sourceDirectory,String targetDirectory) {
		this.sourceDirectory=sourceDirectory;
		this.targetDirectory=targetDirectory;
	}
	
	@Override
	public TaskStatus execute(String fileName, int feedId, int runId) {
		
		try {
			File src=new File(sourceDirectory,fileName);
			File trgt=new File(targetDirectory,fileName);
			//log.info("Moving file from "+src.getAbosulatePath()+"to "+trgt.get);
			
			//need to enable below
			FileUtils.copyFile(src, trgt);
			
			FileUtils.forceDelete(src);
		}
	catch(IOException e) {
		//log.error("");
		return TaskStatus.failedStatus(e.getMessage());
	}
		// TODO Auto-generated method stub
		return TaskStatus.successStatus();
	}

}
