package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import javax.batch.operations.JobRestartException;
import javax.batch.runtime.JobExecution;

import org.apache.catalina.core.ApplicationContext;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class BatchRunner {
	public static void main(String[] args) throws JobRestartException, NumberFormatException,
			JobParametersInvalidException, JobExecutionAlreadyRunningException, JobInstanceAlreadyCompleteException {
		if (args.length < 5) {
			throw new IllegalArgumentException("");
		}
		BatchRunner runner = new BatchRunner();

		AnnotationConfigApplicationContext context = new JobContextFactory().createContext(args[0],
				Integer.parseInt(args[1]));

		String fileName = args[0];
		int feedId = Integer.parseInt(args[1]);

		int runId = Integer.parseInt(args[2]);
		// log.info("");
		boolean success;
		try {
			success = runner.executeJob(context, args[0], Integer.parseInt(args[1]), Integer.parseInt(args[2]),
					args[3], args[4]);
		
		if(success) {
			//log.info("Job completed succesfully");
		}
		else {
			//log.info("Job completed with errors");
		} }
		catch (org.springframework.batch.core.repository.JobRestartException e) {
			e.printStackTrace();
		}

	}

	private boolean executeJob(AnnotationConfigApplicationContext context, String fileName, Integer feedId,
			Integer runId, String header, String footer)
			throws JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException,
			JobInstanceAlreadyCompleteException, org.springframework.batch.core.repository.JobRestartException {

		Map<String, JobParameter> parameterMap = new HashMap<>();
		parameterMap.put(AbstractConfiguration.FILE_NAME_KEY, new JobParameter(fileName));
		parameterMap.put(AbstractConfiguration.FEED_ID_KEY, new JobParameter(feedId.longValue()));
		parameterMap.put(AbstractConfiguration.RUN_ID_KEY, new JobParameter(runId.longValue()));
		parameterMap.put(AbstractConfiguration.HEADER_PATTERN_KEY, new JobParameter(header));
		parameterMap.put(AbstractConfiguration.HEADER_PATTERN_KEY, new JobParameter(header));

		JobLauncher jobLauncher = context.getBean(JobLauncher.class);
		Job job = context.getBean(Job.class);
		org.springframework.batch.core.JobExecution jobExe = jobLauncher.run(job, new JobParameters(parameterMap));

		return ExitStatus.COMPLETED.equals(jobExe.getExitStatus());

	}
}
