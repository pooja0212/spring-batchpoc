package com.example.demo;

public interface ProcessingTask {
	TaskStatus execute(String fileName,int feedId,int runId);

}
