package com.example.demo;

public interface PostProcessingTask  extends ProcessingTask {

}
