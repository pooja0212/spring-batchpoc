package com.example.demo;

import java.util.List;

import javax.batch.api.chunk.ItemWriter;

public abstract class FeedItemWriter<T extends FeedItem> implements ItemWriter<T> {
	protected int feedId;
	
	public void write(List<? extends T> items) throws Exception{
		writeItems(items);
	}

	protected abstract void writeItems(List<? extends T> items) throws Exception;
	

}
