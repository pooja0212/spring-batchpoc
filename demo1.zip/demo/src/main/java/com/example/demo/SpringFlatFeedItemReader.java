package com.example.demo;

import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.separator.SimpleRecordSeparatorPolicy;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.core.io.FileSystemResource;

import com.example.demo.SpringFlatFeedItemReader.SpringFlatFeedItemReaderBuilder;

public class SpringFlatFeedItemReader<T> extends FeedItemReader<T> implements ItemStream {

	private FlatFileItemReader<T> fileReader;

	private SpringFlatFeedItemReader(String baseLocation, String fileName, String[] dtoFieldsName,
			Class<? extends T> dtoClass, String delimiter, int linesToSkip, String[] comments) {
		DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setNames(dtoFieldsName);
		lineTokenizer.setDelimiter(delimiter);

		BeanWrapperFieldSetMapper<T> filedSetMapper = new BeanWrapperFieldSetMapper<T>();
		filedSetMapper.setTargetType(dtoClass);

		DefaultLineMapper<T> defaultLineMapper = new DefaultLineMapper<>();
		defaultLineMapper.setLineTokenizer(lineTokenizer);
		defaultLineMapper.setFieldSetMapper(filedSetMapper);

		this.fileReader = new FlatFileItemReader<T>();
		this.fileReader.setResource(new FileSystemResource(baseLocation + "/" + fileName));
		this.fileReader.setLinesToSkip(linesToSkip);
		this.fileReader.setComments(comments);
		this.fileReader.setLineMapper(defaultLineMapper);
		/**
		 * while file processing last couple of lines was not reading and writting to
		 * table root cause of issue is chunk size it was ignoring last one or couple of
		 * lines.
		 * 
		 * we used below to resolve the similar types of issue
		 */
		this.fileReader.setRecordSeparatorPolicy(new SimpleRecordSeparatorPolicy() {
			public boolean isEndofRecord(final String line) {
				return line.trim().length() != 0 && super.isEndOfRecord(line);
			}

			public String postProcess(final String record) {
				if (record == null || record.trim().length() == 0) {
					return null;
				}
				return super.postProcess(record);
			}

		});

	}

	@Override
	public void open(ExecutionContext executionContext) throws ItemStreamException {

		fileReader.open(executionContext);
	}

	@Override
	public void update(ExecutionContext executionContext) throws ItemStreamException {

		fileReader.update(executionContext);
	}

	@Override
	public void close() throws ItemStreamException {
		fileReader.close();
	}

	@Override
	protected T doRead() throws Exception {
		return fileReader.read();
	}

	public static <T> SpringFlatFeedItemReaderBuilder builder() {
		return new SpringFlatFeedItemReaderBuilder<T>();
	}

	public static class SpringFlatFeedItemReaderBuilder<T> {
		private String fileName;
		private String fileLocation;
		private String delimiter = ",";
		private int linesToSkip = 1;
		private Class<?> dtoClass;
		private String[] dtoFieldsName;
		private String[] comments;

		public SpringFlatFeedItemReaderBuilder fileName(String fileName) {
			this.fileName = fileName;
			return this;
		}

		public SpringFlatFeedItemReaderBuilder fileLocation(String fileLocation) {
			this.fileLocation = fileLocation;
			return this;
		}

		public SpringFlatFeedItemReaderBuilder delimiter(String delimiter) {
			this.delimiter = delimiter;
			return this;
		}

		public SpringFlatFeedItemReaderBuilder linesToSkip(int linesToSkip) {
			this.linesToSkip = linesToSkip;
			return this;
		}

		public SpringFlatFeedItemReaderBuilder dtoClass(Class<? extends T> dtoClass) {
			this.dtoClass = dtoClass;
			return this;
		}

		public SpringFlatFeedItemReaderBuilder dtoFieldsName(String[] dtoFieldsName) {
			this.dtoFieldsName = dtoFieldsName;
			return this;
		}

		public SpringFlatFeedItemReaderBuilder linesToSkip(String[] comments) {
			this.comments = comments;
			return this;
		}
		
		public SpringFlatFeedItemReader<T> build(){
			return new SpringFlatFeedItemReader(fileLocation, fileName, dtoFieldsName, dtoClass, delimiter, linesToSkip, comments);
		}

	}

}