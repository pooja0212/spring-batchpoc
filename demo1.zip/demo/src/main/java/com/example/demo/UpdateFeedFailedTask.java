package com.example.demo;

import org.springframework.jdbc.core.JdbcTemplate;

public class UpdateFeedFailedTask implements ProcessingTask {

	private JdbcTemplate jdbcTemplate;
	
	public UpdateFeedFailedTask(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate=jdbcTemplate;
	}
	@Override
	public TaskStatus execute(String fileName, int feedId, int runId) {
	int rows=this.jdbcTemplate.update("update statement ",
			ps->{
				ps.setInt(1, feedId);

				ps.setInt(2, runId);
			}
			);
	//log.info("updated mst_feed_status_id to ctrl_feed_processing "+rows);
		return rows >0? TaskStatus.successStatus():TaskStatus.failedStatusButContinue("unable to update feed Status");
	}

}
