package com.example.demo;

import java.sql.Types;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;

public class ThresholdCheckTask extends StoredProcedureImpl implements PostProcessingTask {

	private static final String PROC_NAME = "pkg.thresholdCheck";

	public ThresholdCheckTask(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PROC_NAME);
	}

	public void init() {
		SqlParameter feedId = new SqlParameter("feedid", Types.INTEGER);
		SqlParameter runId = new SqlParameter("runID", Types.INTEGER);
		this.prepareProcedureCall(feedId, runId);
	}

	@Override
	public TaskStatus execute(String fileName, int feedId, int runId) {

		this.executeProcedure(feedId, runId);
		String sql = "SELECT COUNT(1) FROM ctrl_feed_processing cfp, mst_feed_status mfs where cfp.mst_feed_status id"
				+ " = mfs.mst_feed_status_id  AND UPPER(msf.status_name) =upper('Feed Loaded') AND cfp.feed_id= ? AND cfp.run_id = ?";

		Integer result = this.getJdbcTemplate().queryForObject(sql, Integer.class, feedId, runId);
		// .log.info("Threshold check resut value {}, "+ result);

		return result == 0 ? TaskStatus.failedStatus("threshold checkfailed") : TaskStatus.successStatus();
	}

}
