package com.example.demo;

public abstract class FeedValidator<I,O> implements org.springframework.batch.item.ItemProcessor<I, O>{

	@Override
	public O process(I item) throws Exception{
		validate(item);
		return (O) item;
	}
	
	protected abstract boolean validate(I item);
}
