package com.example.demo;

import org.springframework.batch.item.ItemReader;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class FeedItemReader<T> implements ItemReader<T> {

	@Autowired
	protected FeedLoadingListener monitor;
	
	public void setFeedLoadingListener(FeedLoadingListener monitor) {
		this.monitor=monitor;
		
	}
	@Override
	public T read() {
		
		try {
		return doRead();
		
		}
		catch(Exception e) {
			//log.error("error occured during file reading ",e);
			monitor.onError(e);
		}
		return null;
	}
	protected abstract T doRead() throws Exception;
	
	
}
