package com.example.demo;

import javax.batch.runtime.JobExecution;

public interface JobExecutionListner {
/**
 * Callback before a job executions
 * @param jobExecution
 */
	
	void beforeJob(org.springframework.batch.core.JobExecution jobExecution);
	/**
	 * Callback after completion of Job.call
	 * @param jobExecution
	 */
	
	//need to add comment
	void afterJob(org.springframework.batch.core.JobExecution jobExecution);
}
