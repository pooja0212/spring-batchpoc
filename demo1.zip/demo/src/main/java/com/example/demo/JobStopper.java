package com.example.demo;

import org.springframework.batch.core.JobExecution;

public class JobStopper {

	
	public void stop(JobExecution jobExecution) {
		jobExecution.stop();
		
	}
}
