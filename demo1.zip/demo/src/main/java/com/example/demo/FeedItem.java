package com.example.demo;


public class FeedItem {

	protected String validationStatus;
	protected StringBuilder errorDesc;
}
