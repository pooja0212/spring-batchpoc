package com.example.demo;

import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlCall;
import org.springframework.jdbc.object.StoredProcedure;

public class StoredProcedureImpl extends StoredProcedure{

	public StoredProcedureImpl(JdbcTemplate jdbcTemplate,String procName) {
		super(jdbcTemplate,procName);
	}
	
	protected void prepareProcedureCall(SqlParameter ...sqlparams) {
		this.setParameters(sqlparams);
		this.compile();
	}
	public Map<String, Object> executeProcedure(Object ...inParams){
		try {
			return this.execute(inParams);
		}
		catch (Exception e) {
			// TODO: handle exception
			//log.error();
			return null;
		}
	}
}
