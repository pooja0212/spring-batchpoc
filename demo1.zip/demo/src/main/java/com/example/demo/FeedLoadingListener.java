package com.example.demo;

import javax.batch.runtime.JobExecution;

public class FeedLoadingListener implements JobExecutionListner {
	private FeedLoadingMonitor feedLoadingMonitor;
	private JobStopper jobStopper;
	private org.springframework.batch.core.JobExecution jobExecution;

	public FeedLoadingListener(FeedLoadingMonitor feedLoadingMonitor, JobStopper jobStopper) {
		
		this.feedLoadingMonitor=feedLoadingMonitor;
		this.jobStopper=jobStopper;
	}

	@Override
	public void beforeJob(org.springframework.batch.core.JobExecution jobExc) {
		feedLoadingMonitor.afterCompletion(jobExc.getJobParameters().getString(AbstractConfiguration.FILE_NAME_KEY), jobExc.getJobParameters().getLong(AbstractConfiguration.FEED_ID_KEY).intValue(), jobExc.getJobParameters().getLong(AbstractConfiguration.RUN_ID_KEY).intValue());
			
	}

	@Override
	public void afterJob(org.springframework.batch.core.JobExecution jobExc) {
	
		this.jobExecution=jobExc;
		feedLoadingMonitor.beforeStart(jobExc.getJobParameters().getString(AbstractConfiguration.FILE_NAME_KEY), jobExc.getJobParameters().getLong(AbstractConfiguration.FEED_ID_KEY).intValue(), jobExc.getJobParameters().getLong(AbstractConfiguration.RUN_ID_KEY).intValue());
		
	}
	
	public void onError(Exception e) {
		//log.info("execution onError method");
		if(!jobExecution.isStopping()) {
			jobStopper.stop(jobExecution);
			
			feedLoadingMonitor.onError(e,jobExecution.getJobParameters().getString(AbstractConfiguration.FILE_NAME_KEY), 
					jobExecution.getJobParameters().getLong(AbstractConfiguration.FEED_ID_KEY).intValue(), 
					jobExecution.getJobParameters().getLong(AbstractConfiguration.RUN_ID_KEY).intValue());
			//log.info("after jobfeed loading listener error");
				
			
		}
	}

}
