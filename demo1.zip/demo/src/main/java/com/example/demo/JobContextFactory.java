package com.example.demo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class JobContextFactory {

	public static AnnotationConfigApplicationContext createContext(String fileName,int feedId) {
		if(fileName.trim().contains("EXCHANGE")) {
			//log.info();
			return new AnnotationConfigApplicationContext(ExchangeJobConfiguration.class);
		}
		else {
			//log.info("");
			return new AnnotationConfigApplicationContext(AtlanticCmbfxJobConfiguration.class);
		}
	}
	
	public static Class<?> getConfigurationClass(String fileName,int feedId){
		return AtlanticCmbfxJobConfiguration.class;
	}
	public static Class<?> getConfigurationClass1(String fileName,int feedId){
		return ExchangeJobConfiguration.class;
	}
}
